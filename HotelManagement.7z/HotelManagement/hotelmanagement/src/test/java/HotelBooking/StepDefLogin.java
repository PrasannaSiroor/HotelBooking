package HotelBooking;

import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDefLogin {
	
	
	@Given("^User is in hotel booking page$")
	public void user_is_in_hotel_booking_page() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^Check the title of the page$")
	public void check_the_title_of_the_page() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Given("^User is on hotel booking page$")
	public void user_is_on_hotel_booking_page() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@When("^User enters all valid data$")
	public void user_enters_all_valid_data() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^navigate to welcome page$")
	public void navigate_to_welcome_page() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Given("^Uer is on hotel booking page$")
	public void uer_is_on_hotel_booking_page() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@When("^user leaves first name blank$")
	public void user_leaves_first_name_blank() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@When("^clicks the button$")
	public void clicks_the_button() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^display alert msg$")
	public void display_alert_msg() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@When("^user leaves last Name blank and clicks the button$")
	public void user_leaves_last_Name_blank_and_clicks_the_button() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@When("^user enters all data$")
	public void user_enters_all_data() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@When("^user enters incorrect email format and clicks the button$")
	public void user_enters_incorrect_email_format_and_clicks_the_button() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Given("^user is on hotel booking page$")
	public void user_is_on_hotel_booking_page1() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@When("^user leaves Mobilemno blank and clicks the button$")
	public void user_leaves_Mobilemno_blank_and_clicks_the_button() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@When("^User Doesnot select adress$")
	public void user_Doesnot_select_adress() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@When("^User doesnot select city$")
	public void user_doesnot_select_city() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@When("^User doesnot select state$")
	public void user_doesnot_select_state() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@When("^User enters <numberOfGuests>$")
	public void user_enters_numberOfGuests() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^aloocate rooms such that (\\d+)  from minimum (\\d+) guests$")
	public void aloocate_rooms_such_that_from_minimum_guests(int arg1, int arg2) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@When("^user leaves CardHoldername blank and clicks the button$")
	public void user_leaves_CardHoldername_blank_and_clicks_the_button() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@When("^user leaves DebitHolderName blank and clicks the button$")
	public void user_leaves_DebitHolderName_blank_and_clicks_the_button() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}



}
