package HotelBooking;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;

public class SeleniumBookingPage {
	
	public static void main(String args[]) throws InterruptedException {
		
		
		WebDriver driver = new FirefoxDriver();
		driver.get("file:///D:/Module4/Module%203/hotelBooking/hotelbooking.html");
		String title = driver.getTitle();
		System.out.println("The page title is:" + title);
		
		
		
		
		/**********************First Name********************************************************/
	     driver.findElement(By.name("txtFN")).sendKeys("");
	     driver.findElement(By.id("btnPayment")).click();
	     String alertMessage1=driver.switchTo().alert().getText();
	     System.out.println(alertMessage1);
	 	Thread.sleep(3000);
	     driver.switchTo().alert().accept();
	             Thread.sleep(3000);
	     driver.findElement(By.name("txtFN")).sendKeys("Prasanna");      
	     
	     
	     
	     
	/*********************************Last Name**********************************************/     
		
	   
	   
	     driver.findElement(By.xpath("//*[@id='txtLastName']")).sendKeys();  
	     driver.findElement(By.id("btnPayment")).click();
	     String alertMessage2=driver.switchTo().alert().getText();
	     System.out.println(alertMessage2);
	     Thread.sleep(3000);
	     driver.switchTo().alert().accept();
	     Thread.sleep(3000);
	     driver.findElement(By.name("txtLN")).sendKeys("Siroor");
	     
	     
	     
	     
	 /*******************  For  Blank EmailID  *****************************************************/
	    
	     driver.findElement(By.name("Email")).sendKeys("");
	     driver.findElement(By.id("btnPayment")).click();
	     String alertMessage3=driver.switchTo().alert().getText();
	     System.out.println(alertMessage3);
	     driver.switchTo().alert().accept();
	    	//Thread.sleep(3000);			
   // driver.findElement(By.xpath("//[@id='txtEmail']")).sendKeys();

	     
	     

	   /************************For Invalid Email Id**************************/
	     
	     driver.findElement(By.name("Email")).sendKeys("a.com");
	     driver.findElement(By.id("btnPayment")).click();
	     String alertMessage4=driver.switchTo().alert().getText();
	     System.out.println(alertMessage4);
	     driver.switchTo().alert().accept();
	     
	     driver.findElement(By.name("Email")).clear();
	     driver.findElement(By.name("Email")).sendKeys("spkumari058@gmail.com");
	     
	     
	     
	     
	    
    /*************************** For Invalid Phone Number**************************/	
	     driver.findElement(By.cssSelector("input[pattern='[789][0-9]{9}']")).sendKeys(""); 
	   //  driver.findElement(By.name("Phone")).sendKeys("");
	     driver.findElement(By.id("btnPayment")).click();
	     String alertMessage5=driver.switchTo().alert().getText();
	     System.out.println(alertMessage5);
	     driver.switchTo().alert().accept();
	     
	     
	     
	     
	     
	    /****************************for valid Phone Number **********************************/ 
			
	     driver.findElement(By.cssSelector("input[pattern='[789][0-9]{9}']")).clear();
	     driver.findElement(By.cssSelector("input[pattern='[789][0-9]{9}']")).sendKeys("8497992099");
	     
	     
	     
	     
	     
	     /***************************For Blank city******************************************/
	     
	     Select drpCity = new Select(driver.findElement(By.name("city")));
	     driver.findElement(By.id("btnPayment")).click();
	     String alertMessage6=driver.switchTo().alert().getText();
	     System.out.println(alertMessage6);
	     driver.switchTo().alert().accept();
	     
	     
	     /**********************select City ********************************/
	 	Select drpCity1 = new Select(driver.findElement(By.name("city")));
	 	          drpCity1.selectByValue("Pune");
	 	          Thread.sleep(3000);
	 	          
	 	         /***************************For Blank state*****************************************/
	 		     
	 		     Select drpState = new Select(driver.findElement(By.name("state")));
	 		     driver.findElement(By.id("btnPayment")).click();
	 		     String alertMessage11=driver.switchTo().alert().getText();
	 		     System.out.println(alertMessage11);
	 		     driver.switchTo().alert().accept();
	 		     
	     
	     
	     /**********************select State ********************************/
	 	Select drpState1 = new Select(driver.findElement(By.name("state")));
	 	          drpState1.selectByValue("Maharashtra");
	 	          Thread.sleep(3000);
	 	          
	 	          
	 	          
	   /***************************Blank Debit Card Number***********************/ 
	 	          
	 	          driver.findElement(By.id("txtCardholderName")).sendKeys("");
	 	         driver.findElement(By.id("btnPayment")).click();
	 	         Thread.sleep(30000);
	 	        String alertMessage7=driver.switchTo().alert().getText();
	 		     System.out.println(alertMessage7);
	 		    
	 		     driver.switchTo().alert().accept();
	 		    Thread.sleep(3000);
	 		     
   /**************************Valid CardHolder**************************/
	 		     driver.findElement(By.id("txtCardholderName")).sendKeys("Prasanna");
	 		     Thread.sleep(3000);
	 		     
	 		     /******************Blank Debit card******************/
	 		     
	 		    driver.findElement(By.id("txtDebit")).sendKeys("");
	 	         driver.findElement(By.id("btnPayment")).click();
	 	         Thread.sleep(30000);
	 	        String alertMessage12=driver.switchTo().alert().getText();
	 		     System.out.println(alertMessage12);
	 		    
	 		     driver.switchTo().alert().accept();
	 		     
 /****************************Valid Debit Card************************/
	 		     
	 		     driver.findElement(By.id("txtDebit")).sendKeys("9640 4456 4538");
	 		     Thread.sleep(3000);
	 		     
	 		     
  /***********************************Blank CVV*********************/
	 		     
	 		    driver.findElement(By.id("txtCvv")).sendKeys("");
	 		    driver.findElement(By.id("btnPayment")).click();
	 		     String alertMessage8=driver.switchTo().alert().getText();
	 		     Thread.sleep(3000);
	 		     System.out.println(alertMessage8);
	 		     driver.switchTo().alert().accept();
	 		    
	 		     
	 		     
	 		     
 /*************************Valid CVV***********************/
	 		     driver.findElement(By.id("txtCvv")).sendKeys("444");
	 		     Thread.sleep(3000);
/******************************************************* Blank Month*********************************/
	 		     
	 		    driver.findElement(By.id("txtMonth")).sendKeys("");
	 		    driver.findElement(By.id("btnPayment")).click();
	 		     String alertMessage9=driver.switchTo().alert().getText();
	 		     Thread.sleep(3000);
	 		     System.out.println(alertMessage9);
	 		     driver.switchTo().alert().accept();
	 		 
	 		     
/*********************************************Valid Month**************************/
	 		     
	 		    driver.findElement(By.id("txtMonth")).sendKeys("April");
	 		     Thread.sleep(3000);  
	 		     
	 		     
/************************************************************** Blank Year*********************************/
	 		     
	 		    driver.findElement(By.id("txtYear")).sendKeys("");
	 		    driver.findElement(By.id("btnPayment")).click();
	 		     String alertMessage10=driver.switchTo().alert().getText();
	 		     Thread.sleep(3000);
	 		     System.out.println(alertMessage10);
	 		     driver.switchTo().alert().accept();
	 		    
	 		     
/*********************************************Valid Year**************************/
	 		     
		 		    driver.findElement(By.id("txtYear")).sendKeys("2022");
		 		     Thread.sleep(3000);  
		 		       driver.findElement(By.className("btn")).click();   
		 		       driver.navigate().to("file:///D:/Module4/Module%203/hotelBooking/success.html");
	 		     
	 		     
	}
	
	
	
	

}
