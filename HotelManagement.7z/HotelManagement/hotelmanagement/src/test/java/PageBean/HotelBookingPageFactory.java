package PageBean;

public class HotelBookingPageFactory {

}
