package HotelLogin;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class SeleniumHotelLogin {
	public static void main(String[] args) throws Exception {
		
		
		WebDriver driver = new FirefoxDriver();
		driver.get("file:///D:/Module4/Module%203/hotelBooking/login.html");
		String strheading = driver.findElement(By.xpath("//*[@id='mainCnt']/div[1]/div[1]/h1")).getText();
		if(strheading.contentEquals("Hotel Booking Application"))
		{
			System.out.println("Heading Matched");
			

	                     Thread.sleep(3000);	
		
	        driver.findElement(By.name("userName")).sendKeys("capgemini");
	
	                    Thread.sleep(3000);
	     	driver.findElement(By.name("userPwd")).sendKeys("capg1234");
	     	
	     	
	 /************************invalid password**************************/
	     //driver.findElement(By.name("userPwd")).sendKeys("capg12");     
	/*****************************************************************/
	     	
	                        Thread.sleep(3000);
	      	
	        driver.findElement(By.className("btn")).click();
	             String alertMessage=driver.switchTo().alert().getText();
	             System.out.println(alertMessage);
	             driver.switchTo().alert().accept();
			driver.navigate().to("file:///D:/Module4/Module%203/hotelBooking/login.html");	
		}
		else {
			 System.out.println("Heading Not Matched");
		}
	
	
		driver.close();
		driver.quit();		
          
}
}